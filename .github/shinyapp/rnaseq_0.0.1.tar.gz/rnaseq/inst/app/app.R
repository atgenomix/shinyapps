# For compatibility with Shiny Server

rnaseq::runShiny()